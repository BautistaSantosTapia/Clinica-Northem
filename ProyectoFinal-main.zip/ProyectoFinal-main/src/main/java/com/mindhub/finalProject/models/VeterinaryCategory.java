package com.mindhub.finalProject.models;

public enum VeterinaryCategory {
    CARDIOLOGO,
    CIRUJANO,
    OFTALMOLOGO,
    CLINICO
}
