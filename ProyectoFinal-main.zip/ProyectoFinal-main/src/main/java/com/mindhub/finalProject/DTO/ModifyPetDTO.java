package com.mindhub.finalProject.DTO;

public class ModifyPetDTO {
    private long id;
   private int age;
   private float weigth;

    public ModifyPetDTO() {
    }


    /*GETTERS*/

    public long getId() {
        return id;
    }

    public int getAge() {
        return age;
    }

    public float getWeigth() {
        return weigth;
    }
}
