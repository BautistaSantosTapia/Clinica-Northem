package com.mindhub.finalProject.models;

public enum ProductCategory {
    VACCINE,
    MEDICINE,
    BALANCED_MEAL,
    TOY
}
