package com.mindhub.finalProject.models;

public enum PetType {
    PERRO,
    GATO,
    HAMSTER,
    LORO,
    CABALLO,
    CONEJO,
    TORTUGA
}
