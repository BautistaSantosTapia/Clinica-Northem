package com.mindhub.finalProject.models;

public enum Authority {
    ADMIN,
    VETERINARY,
    CLIENT
}
